import java.util.Scanner;

//Элвис Пресли жил с 1935 по 1977 год.
// Используя тернарные операторы, напишите программу,
// в которой пользователь вводит год. Если указанный год меньше 1935,
// то вывести «Элвис ещё не родился».
// Если указанный пользователем год с 1935 по 1977 включительно,
// то вывести «Элвис жив!». Если введённый пользователем год больше 1977,
// то вывести «Элвис навсегда в наших сердцах!»
public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите год: ");
        int userYear = scn.nextInt();

        System.out.println(userYear >= 1977 ? "Элвис навсегда в наших сердцах!" : "");
        System.out.println(userYear <= 1935 ? "Элвис ещё не родился!" : "");
        // c = userYear !a && !b ? "Элвис жив!" : "";
        System.out.println(userYear = 1936  );




    }
}