//Создать программу, выводящую на экран ближайшее к 10 из двух чисел,
// записанных в переменные m и n.
//Числа могут быть, как целочисленные, так и дробные.
//
//Например:
//ввод: m=7, n=11
//вывод: Число 11 ближе к 10.

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите первое ближащее число: ");
        double num1 = scn.nextInt();
        System.out.println("Введите второе ближащее число: ");
        double num2 = scn.nextInt();
        double rez1 = 10 - Math.abs(num1);
        double rez2 = 10 - Math.abs(num2);


        if(rez1 < rez2){
            System.out.println("Число " + num1 + "ближе к 10");
        }else{
            System.out.println("Число " + num2 + "ближе к 10");
        }
    }
}